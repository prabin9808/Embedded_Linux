/home/prabinku/BeagleBone_WorkSpace/ldd/custom_drivers/002pseudo_char_driver/pcd.o

